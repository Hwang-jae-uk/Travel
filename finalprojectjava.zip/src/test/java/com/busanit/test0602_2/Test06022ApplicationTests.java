package com.busanit.travelapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test06022ApplicationTests {

    @Test
    void contextLoads() {
    }

}
