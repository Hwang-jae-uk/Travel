package com.busanit.travelapp.repository;

import com.busanit.travelapp.entity.Cafe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CafeRepository extends JpaRepository<Cafe, Long> {

}