package com.busanit.travelapp.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RestaurantImageDTO {
    private Long id;
    private String imagePath;
    private Long restaurantId;
} 